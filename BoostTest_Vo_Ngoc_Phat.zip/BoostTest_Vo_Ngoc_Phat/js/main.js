$(document).ready(function() {
  let $btnFilter = $('#filterBtn');
  let $btnClose = $('.close-btn');
  let $overlay = $('.overlay');
  let $filterPopup = $('.filter');
  let $btnFooter = $('.filter__footer-btn');

  $btnFilter.click(function() {
    $filterPopup.fadeIn();
    $overlay.fadeIn();
    $btnClose.fadeIn();
    calc();
  });

  $btnClose.add($overlay).click(function() {
    $filterPopup.fadeOut();
    $overlay.fadeOut();
    $btnClose.fadeOut();
  });

  $btnFooter.click(function() {
    $btnClose.trigger('click');
  });

  $(window).resize(function() {
    calc();
  });
});

function calc() {
  let $window = $(window);
  let $filter = $('.filter');
  let $btnTop = $('.top-btn');
  let $filterList = $('.filter__list');
  let $filterHeader = $('.filter__header');
  let $filterFooter = $('.filter__footer');

  let wWindow = $window.width();
  let wFilter = $filter.width();
  let hWindow = $window.height();
  let hFilter = $filter.height();
  let filterHeaderHeight = $filterHeader.outerHeight();
  let filterFooterHeight = $filterFooter.outerHeight();
  let posLeft = (wWindow - wFilter) / 2;
  let posTop = (hWindow - hFilter) / 2;  
  let hFilterList = hWindow - (filterHeaderHeight + filterFooterHeight);

  $filterList.css({
    'height': hFilterList,
    'overflow-y': 'auto'
  });

  if(wWindow > 1024) {
    $btnTop.css({
      'left': posLeft - $btnTop.width(),
      'top': posTop
    });
  } else {
    $btnTop.css({
      'left': posLeft + wFilter - $btnTop.width(),
      'top': posTop
    })
  }
}